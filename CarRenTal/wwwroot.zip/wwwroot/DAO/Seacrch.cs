﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarRenTal.wwwroot.DAO
{
    public class Seacrch
    {

        public static string LoaiXe;

        public static string Tinh;

        public static string Huyen;
        public static DateTime ngaynhan;
        public static DateTime ngaytra;
        public static double daydiff;
        public static double tongtien;

        public static int mahang;

    }
}
